<?php
session_start();
if (!isset($_SESSION["admin"])) {
    header("Location: ../index.html");
    exit;
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Admin Dashboard - Inventory</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body { background:#f8f9fa; }
        .card-hover:hover { transform: scale(1.03); transition: 0.3s; }
        .sidebar {
            background: #198754;
            height: 100vh;
            padding: 20px;
            position: fixed;
        }
        .sidebar a {
            display: block;
            color: white;
            padding: 12px;
            margin: 5px 0;
            border-radius: 8px;
            text-decoration: none;
        }
        .sidebar a:hover { background: #0d5f34; }
        .content-area { margin-left: 250px; padding: 30px; }
        .table-hover tbody tr:hover { background:#e8ffe8; }
    </style>
</head>

<body>

<!-- LEFT SIDEBAR -->
<div class="sidebar">
    <h4 class="text-white">Admin Panel</h4>
    <hr class="bg-light">
    <a href="#" onclick="showSection('stocks')">📦 Stocks</a>
    <a href="#" onclick="showSection('addStock')">➕ Add Stock</a>
    <a href="#" onclick="showSection('addProduct')">🛠 Add Product</a>
    <a href="#" onclick="showSection('orders')">🧾 Orders</a>
    <hr class="bg-light">
    <a href="../php/logout.php" class="bg-danger">🚪 Logout</a>
</div>

<!-- MAIN AREA -->
<div class="content-area">

    <!-- STOCKS SECTION -->
    <div id="stocks" class="section">
        <h2>📦 Stock Details</h2>
        <div class="table-responsive mt-3">
            <table class="table table-bordered table-hover">
                <thead class="table-success">
                    <tr>
                        <th>Category</th>
                        <th>Product Name</th>
                        <th>Model</th>
                        <th>Price (₹)</th>
                        <th>Available Qty</th>
                        <th>Unit</th>
                        <th>Low Stock?</th>
                    </tr>
                </thead>
                <tbody id="stockTable"></tbody>
            </table>
        </div>
    </div>

    <!-- ADD STOCK SECTION -->
    <div id="addStock" class="section" style="display:none;">
        <h2>➕ Add Stock (1 Unit = 12 Items)</h2>
        <form class="mt-3" id="addStockForm">
            <div class="mb-3">
                <label>Select Product</label>
                <select class="form-control" id="stockProduct" required></select>
            </div>
            <button class="btn btn-success">Add 12 Items</button>
        </form>
    </div>

    <!-- ADD PRODUCT SECTION -->
    <div id="addProduct" class="section" style="display:none;">
        <h2>🛠 Add New Product</h2>
        <form class="mt-3" id="addProductForm">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label>Category</label>
                    <select class="form-control" name="category" required>
                        <option>electronic</option>
                        <option>kitchen</option>
                        <option>grocery</option>
                        <option>dress</option>
                    </select>
                </div>
                <div class="col-md-6 mb-3">
                    <label>Product Name</label>
                    <input type="text" class="form-control" name="product_name" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label>Model</label>
                    <input type="text" class="form-control" name="model" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label>Price (₹)</label>
                    <input type="number" class="form-control" name="price" required>
                </div>
                <div class="col-md-12 mb-3">
                    <label>Description</label>
                    <textarea class="form-control" name="description"></textarea>
                </div>
            </div>
            <button class="btn btn-primary">Add Product</button>
        </form>
    </div>

    <!-- ORDERS SECTION -->
    <div id="orders" class="section" style="display:none;">
        <h2>🧾 Customer Orders</h2>
        <div class="table-responsive mt-3">
            <table class="table table-bordered table-hover">
                <thead class="table-success">
                    <tr>
                        <th>Customer</th>
                        <th>Email</th>
                        <th>Category</th>
                        <th>Product</th>
                        <th>Model</th>
                        <th>Qty</th>
                        <th>Price (₹)</th>
                        <th>Order Time</th>
                    </tr>
                </thead>
                <tbody id="orderTable"></tbody>
            </table>
        </div>
    </div>

</div>

<script>
// Switch between menu sections
function showSection(id) {
    document.querySelectorAll(".section").forEach(s => s.style.display = "none");
    document.getElementById(id).style.display = "block";
}

// Load stock data
function loadStocks() {
    fetch("../php/admin_get_stocks.php")
    .then(res => res.json())
    .then(data => {
        const tbody = document.getElementById("stockTable");
        const select = document.getElementById("stockProduct");

        tbody.innerHTML = "";
        select.innerHTML = "";

        data.forEach(item => {
            tbody.innerHTML += `
                <tr>
                    <td>${item.category}</td>
                    <td>${item.product_name}</td>
                    <td>${item.model}</td>
                    <td>${item.price}</td>
                    <td>${item.quantity}</td>
                    <td>${item.unit}</td>
                    <td>${item.quantity <= 1 ? "<span class='text-danger fw-bold'>LOW</span>" : "OK"}</td>
                </tr>`;

            select.innerHTML += `
                <option value="${item.product_name}|${item.model}">
                    ${item.product_name} - ${item.model}
                </option>`;
        });
    });
}

// Add Stock
document.getElementById("addStockForm").addEventListener("submit", e => {
    e.preventDefault();

    let val = document.getElementById("stockProduct").value;
    let [product_name, model] = val.split("|");

    fetch("../php/admin_add_stock.php", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({ product_name, model })
    })
    .then(res => res.text())
    .then(msg => {
        alert(msg);
        loadStocks();
    });
});

// Add Product
document.getElementById("addProductForm").addEventListener("submit", e => {
    e.preventDefault();

    let form = new FormData(e.target);

    fetch("../php/admin_add_product.php", {
        method: "POST",
        body: form
    })
    .then(res => res.text())
    .then(msg => {
        alert(msg);
        e.target.reset();
        loadStocks();
    });
});

// Load Orders
function loadOrders() {
    fetch("../php/admin_get_orders.php")
    .then(res => res.json())
    .then(data => {
        const tbody = document.getElementById("orderTable");
        tbody.innerHTML = "";

        data.forEach(o => {
            tbody.innerHTML += `
                <tr>
                    <td>${o.customer_name}</td>
                    <td>${o.customer_email}</td>
                    <td>${o.category}</td>
                    <td>${o.product_name}</td>
                    <td>${o.model}</td>
                    <td>${o.quantity}</td>
                    <td>${o.price}</td>
                    <td>${o.order_time}</td>
                </tr>`;
        });
    });
}

loadStocks();
loadOrders();
</script>

</body>
</html>
