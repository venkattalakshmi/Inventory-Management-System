<?php
$DB_HOST = '127.0.0.1';
$DB_PORT = '3306';
$DB_USER = 'root';
$DB_PASS = 'Thisanthan@123';

try {
    $pdo = new PDO(
        "mysql:host=$DB_HOST;port=$DB_PORT;dbname=userdetail;charset=utf8mb4",
        $DB_USER,
        $DB_PASS
    );
    echo "Connected!";
} catch (PDOException $e) {
    die("DB Connection failed: " . $e->getMessage());
}
