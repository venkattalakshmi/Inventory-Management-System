<?php
session_start();
require "db.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo "Invalid request method";
    exit;
}

$usertype = $_POST["usertype"] ?? "";
$username = strtolower(trim($_POST["username"] ?? ""));
$password = $_POST["password"] ?? "";

if (empty($usertype) || empty($username) || empty($password)) {
    echo "<script>alert('All fields are required'); window.location.href='../index.html';</script>";
    exit;
}

try {

    if ($usertype === "admin") {
        // Check admin
        $stmt = $pdo_user->prepare("SELECT * FROM admin WHERE username = :u AND password = :p");
        $stmt->execute([":u" => $username, ":p" => $password]);
        $admin = $stmt->fetch();

        if ($admin) {
            $_SESSION["admin"] = $username;
            header("Location: ../admin/dashboard.html");
            exit;
        }
    }

    if ($usertype === "customer") {
        // Check customer
        $stmt = $pdo_user->prepare("SELECT * FROM customer WHERE username = :u AND password = :p");
        $stmt->execute([":u" => $username, ":p" => $password]);
        $customer = $stmt->fetch();

        if ($customer) {
            $_SESSION["customer"] = $username;
            header("Location: ../customer/order.html");
            exit;
        }
    }

    // Login failed
    echo "<script>
            alert('Invalid credentials!');
            window.location.href='../index.html';
          </script>";

} catch (PDOException $e) {
    echo "<script>
            alert('Database error: " . addslashes($e->getMessage()) . "');
            window.location.href='../index.html';
          </script>";
}
?>
