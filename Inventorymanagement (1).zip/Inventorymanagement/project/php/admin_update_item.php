<?php
// admin_update_item.php
header('Content-Type: application/json');
require_once '../php/db.php'; // your db.php with $pdo_inv

$data = json_decode(file_get_contents('php://input'), true);

if(isset($data['id'], $data['quantity'], $data['unit'])) {
    $id = intval($data['id']);
    $quantity = intval($data['quantity']);
    $unit = trim($data['unit']);

    try {
        // Correct table name is `item`
        $stmt = $pdo_inv->prepare("UPDATE item SET quantity = :quantity, unit = :unit WHERE id = :id");
        $stmt->execute([
            ':quantity' => $quantity,
            ':unit' => $unit,
            ':id' => $id
        ]);

        if($stmt->rowCount() > 0){
            echo json_encode(['success' => true, 'message' => 'Item updated successfully']);
        } else {
            echo json_encode(['success' => false, 'message' => 'No rows updated. Check ID exists.']);
        }

    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'PDO Error: ' . $e->getMessage()]);
    }

} else {
    echo json_encode(['success' => false, 'message' => 'Invalid input']);
}
