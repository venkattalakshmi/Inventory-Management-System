<?php
// admin_add_item.php
header('Content-Type: application/json');
require_once '../php/db.php';

$data = json_decode(file_get_contents('php://input'), true);

if(isset($data['category'], $data['description'], $data['model'], $data['price'], $data['quantity'], $data['unit'])) {
    $category = trim($data['category']);
    $description = trim($data['description']);
    $model = trim($data['model']);
    $price = floatval($data['price']);
    $quantity = intval($data['quantity']);
    $unit = trim($data['unit']);

    try {
        $stmt = $pdo_inv->prepare("INSERT INTO item (category, description, model, price, quantity, unit) VALUES (:category, :description, :model, :price, :quantity, :unit)");
        $stmt->execute([
            ':category' => $category,
            ':description' => $description,
            ':model' => $model,
            ':price' => $price,
            ':quantity' => $quantity,
            ':unit' => $unit
        ]);
        echo json_encode(['success' => true, 'message' => 'New stock added successfully']);
    } catch(PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Add failed: '.$e->getMessage()]);
    }

} else {
    echo json_encode(['success' => false, 'message' => 'Invalid input']);
}
