<?php
require "db.php";
$stmt = $pdo->query("SELECT * FROM inventory_schema.customer_order ORDER BY order_time DESC");
echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
