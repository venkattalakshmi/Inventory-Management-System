<?php
require "db.php";

$stmt = $pdo->prepare("
    INSERT INTO inventory_schema.item
    (category, product_name, model, price, description, quantity, unit)
    VALUES (?,?,?,?,?,0,'unit')
");
$stmt->execute([
    $_POST["category"],
    $_POST["product_name"],
    $_POST["model"],
    $_POST["price"],
    $_POST["description"]
]);

echo "Product added!";
