<?php
require "db.php";

header("Content-Type: application/json");

$product = $_GET['product'] ?? '';

if (!$product) {
    echo json_encode([]);
    exit;
}

$sql = "SELECT model, price, quantity, description 
        FROM item 
        WHERE product_name = ?";
$stmt = $pdo_inv->prepare($sql);
$stmt->execute([$product]);

$data = $stmt->fetchAll();

$models = [];
$price = 0;
$stock = 0;
$desc  = "";

foreach ($data as $row) {
    $models[] = $row['model'];
    $price = $row['price'];
    $stock = $row['quantity'];
    $desc  = $row['description'];
}

echo json_encode([
    "models" => $models,
    "price"  => $price,
    "stock"  => $stock,
    "description" => $desc
]);
?>
