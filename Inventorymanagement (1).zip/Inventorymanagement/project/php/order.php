<?php
session_start();

// For testing, set session if not logged in
// $_SESSION['customer'] = 'test@example.com';
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Place Order - Inventory Management</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <style>
    body { background: #f8f9fa; }
    .tot-box { font-weight: 600; font-size: 1.15rem; }
    .qty-btn { cursor: pointer; padding: 0 10px; border: 1px solid #ccc; user-select: none; }
    .description-box { background: #f1f1f1; padding: 10px; border-radius: 5px; margin-top: 5px; }
  </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-success">
  <div class="container">
    <a class="navbar-brand">Customer Portal</a>
    <div>
      <a href="../php/logout.php" class="btn btn-danger btn-sm">Logout</a>
    </div>
  </div>
</nav>

<div class="container my-4">
  <div class="card p-4 shadow-sm">
    <h3 class="mb-3">Place Order</h3>

    <form id="orderForm" method="POST" action="../php/place_order.php">
      <div class="row g-3">

        <!-- Category -->
        <div class="col-md-4">
          <label class="form-label">Category</label>
          <select id="category" name="category" class="form-select" required>
            <option value="">Select category</option>
            <option value="electronic">Electronic</option>
            <option value="kitchen">Kitchen</option>
            <option value="grocery">Grocery</option>
            <option value="dress">Dress</option>
          </select>
        </div>

        <!-- Product -->
        <div class="col-md-4">
          <label class="form-label">Product</label>
          <select id="product_name" name="product_name" class="form-select" required disabled>
            <option value="">Select product</option>
          </select>
        </div>

        <!-- Model -->
        <div class="col-md-4">
          <label class="form-label">Model</label>
          <select id="model" name="model" class="form-select" disabled>
            <option value="">Select model</option>
          </select>
        </div>

        <!-- Price -->
        <div class="col-md-3">
          <label class="form-label">Price (₹)</label>
          <input id="price" name="price" class="form-control" readonly>
        </div>

        <!-- Available Stock -->
        <div class="col-md-3">
          <label class="form-label">Available</label>
          <input id="stock" class="form-control" readonly>
        </div>

        <!-- Quantity -->
        <div class="col-md-3">
          <label class="form-label">Quantity</label>
          <div class="input-group">
            <span class="qty-btn" id="decQty">-</span>
            <input id="quantity" name="quantity" type="number" class="form-control text-center" value="1" min="1" readonly>
            <span class="qty-btn" id="incQty">+</span>
          </div>
        </div>

        <!-- Total -->
        <div class="col-md-3">
          <label class="form-label">Total (₹)</label>
          <input id="total" class="form-control" readonly value="0">
        </div>

        <!-- Description -->
        <div class="col-12">
          <label class="form-label">Description</label>
          <div id="description" class="description-box">Select a product to see description.</div>
        </div>

        <!-- Customer Info -->
        <div class="col-md-6">
          <label class="form-label">Customer Name</label>
          <input id="customer_name" name="customer_name" type="text" class="form-control" required>
        </div>

        <div class="col-md-6">
          <label class="form-label">Customer Email</label>
          <input id="customer_email" name="customer_email" type="email" class="form-control" 
                 value="<?php echo htmlspecialchars($_SESSION['customer'] ?? ''); ?>" readonly required>
        </div>

        <!-- Submit -->
        <div class="col-12 d-flex justify-content-between align-items-center mt-3">
          <div class="tot-box">Grand Total: ₹ <span id="grandTotal">0.00</span></div>
          <button id="placeBtn" class="btn btn-primary" type="submit" disabled>Place Order</button>
        </div>

      </div>
    </form>
  </div>
</div>

<script>
$(function(){
  function fmt(v){ return Number(v).toFixed(2); }

  // Load products when category changes
  $("#category").on("change", function(){
    const cat = $(this).val();
    $("#product_name").prop("disabled", true).html('<option>Loading...</option>');
    $("#model").prop("disabled", true).html('<option>Select model</option>');
    $("#price,#stock,#total,#description").val('');
    $("#quantity").val(1);
    $("#placeBtn").prop("disabled", true);

    if(!cat){ $("#product_name").html('<option value="">Select product</option>'); return; }

    $.post("../php/fetch_products.php", { category: cat }, function(html){
      $("#product_name").html(html).prop("disabled", false);
    });
  });

  // Load models and details when product changes
  $("#product_name").on("change", function(){
    const prod = $(this).val();
    if(!prod){
      $("#model").prop("disabled", true).html('<option>Select model</option>');
      $("#price,#stock,#total,#description").val('');
      $("#quantity").val(1);
      $("#placeBtn").prop("disabled", true);
      return;
    }

    // Load models
    $.post("../php/fetch_products.php", { product_name: prod, fetch: 'models' }, function(html){
      $("#model").html(html).prop("disabled", false);
    });

    // Load details
    $.post("../php/fetch_products.php", { product_name: prod, fetch: 'details' }, function(json){
      const obj = JSON.parse(json);
      $("#price").val(obj.price || 0);
      $("#stock").val(obj.quantity || 0);
      $("#description").text(obj.description || 'No description available.');
      $("#quantity").val(obj.quantity>0?1:0);
      $("#total").val(fmt((obj.price||0) * (obj.quantity>0?1:0)));
      $("#placeBtn").prop("disabled", obj.quantity<=0);
      updateGrandTotal();
    });
  });

  $("#model").on("change", function(){
    const model = $(this).val();
    const prod  = $("#product_name").val();
    if(!model) return;

    $.post("../php/fetch_products.php", { product_name: prod, model: model, fetch: 'details' }, function(json){
      const obj = JSON.parse(json);
      $("#price").val(obj.price || 0);
      $("#stock").val(obj.quantity || 0);
      $("#quantity").val(obj.quantity>0?1:0);
      $("#total").val(fmt((obj.price||0) * (obj.quantity>0?1:0)));
      $("#placeBtn").prop("disabled", obj.quantity<=0);
      updateGrandTotal();
    });
  });

  // Quantity buttons
  $("#incQty").on("click", function(){
    const max = parseInt($("#stock").val()) || 0;
    let qty = parseInt($("#quantity").val()) || 0;
    if(qty < max) qty++;
    $("#quantity").val(qty);
    updateTotal();
  });
  $("#decQty").on("click", function(){
    let qty = parseInt($("#quantity").val()) || 0;
    if(qty > 1) qty--;
    $("#quantity").val(qty);
    updateTotal();
  });

  function updateTotal(){
    const price = parseFloat($("#price").val()) || 0;
    const qty = parseInt($("#quantity").val()) || 0;
    $("#total").val(fmt(price * qty));
    updateGrandTotal();
  }

  function updateGrandTotal(){
    const tot = parseFloat($("#total").val()) || 0;
    $("#grandTotal").text(fmt(tot));
  }

  $("#orderForm").on("submit", function(e){
    const qty = parseInt($("#quantity").val()) || 0;
    const stock = parseInt($("#stock").val()) || 0;
    if(qty < 1 || qty > stock){
      e.preventDefault();
      alert("Invalid order quantity.");
      return false;
    }
    return true;
  });

});
</script>

</body>
</html>
