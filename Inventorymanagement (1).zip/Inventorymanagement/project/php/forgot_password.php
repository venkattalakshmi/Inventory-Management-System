<?php
// php/forgot_password.php
require 'db.php';
require 'helpers.php';

$usertype = $_POST['usertype'] ?? '';
$username = strtolower(trim($_POST['username'] ?? ''));
$newpass = $_POST['newpass'] ?? '';

if (!filter_var($username, FILTER_VALIDATE_EMAIL) || strlen($newpass) < 8) {
    flash("Invalid input");
    redirect('Location: http://localhost/Inventory%20management/project/');
}

if (!preg_match('/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*\W)/', $newpass)) {
    flash("Password must include upper, lower, number and special char");
    redirect('../forgot_password.html');
}

$hash = password_hash($newpass, PASSWORD_DEFAULT);

try {
    if ($usertype === 'admin') {
        $stmt = $pdo_user->prepare("UPDATE admin SET password = :p WHERE username = :u");
    } else {
        $stmt = $pdo_user->prepare("UPDATE customer SET password = :p WHERE username = :u");
    }
    $stmt->execute([':p' => $hash, ':u' => $username]);
    flash("Password updated. Please login.");
    redirect('../index.html');
} catch (PDOException $e) {
    flash("Error: " . $e->getMessage());
    redirect('../forgot_password.html');
}
