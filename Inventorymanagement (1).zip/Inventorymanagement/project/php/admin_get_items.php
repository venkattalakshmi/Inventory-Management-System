<?php
session_start();
require "db.php";

// Only allow admin
if (!isset($_SESSION['admin'])) {
    echo json_encode([]);
    exit;
}

$stmt = $pdo_inv->query("SELECT * FROM item ORDER BY id ASC");
$items = $stmt->fetchAll(PDO::FETCH_ASSOC);

header('Content-Type: application/json');
echo json_encode($items);
