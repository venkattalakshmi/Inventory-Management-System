<?php
require "db.php";

$stmt = $pdo_inv->query("SELECT * FROM item ORDER BY id DESC");
$items = $stmt->fetchAll();

echo json_encode($items);
?>
