<?php
require "db.php";

// Get POST data
$customer_name    = $_POST['customer_name'] ?? '';
$customer_address = $_POST['customer_address'] ?? '';
$category         = $_POST['category'] ?? '';
$product_name     = $_POST['product_name'] ?? '';
$model            = $_POST['model'] ?? '';
$price            = $_POST['price'] ?? 0;
$quantity         = $_POST['quantity'] ?? 0;
$total            = $_POST['total'] ?? 0;
/*
if (!$customer_name || !$customer_address || !$category || !$product_name || !$model || $quantity < 1) {
    echo "Please fill all required fields correctly.";
    exit;
}*/

try {
    // Start transaction
    $pdo_inv->beginTransaction();

    // Check stock
    $check = $pdo_inv->prepare("SELECT quantity FROM item WHERE product_name = ? AND model = ?");
    $check->execute([$product_name, $model]);
    $stock = $check->fetchColumn();

    if ($stock === false) throw new Exception("Product not found.");
    if ($quantity > $stock) throw new Exception("Requested quantity exceeds available stock.");

    // Insert into customer_order
    $sql = "INSERT INTO customer_order
            (customer_name, customer_address, category, product_name, model, price, quantity, total)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $pdo_inv->prepare($sql);
    $stmt->execute([
        $customer_name,
        $customer_address,
        $category,
        $product_name,
        $model,
        $price,
        $quantity,
        $total
    ]);

    // Reduce stock
    $update = $pdo_inv->prepare("UPDATE item SET quantity = quantity - ? WHERE product_name = ? AND model = ?");
    $update->execute([$quantity, $product_name, $model]);

    $pdo_inv->commit();

    echo "Order placed successfully!";

} catch (Exception $e) {
    $pdo_inv->rollBack();
    echo "Error placing order: " . $e->getMessage();
}
