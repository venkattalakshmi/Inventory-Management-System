<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require "db.php";

try {
    if ($_SERVER["REQUEST_METHOD"] === "POST") {

        $usertype = $_POST["usertype"];
        $username = $_POST["username"];
        $password = $_POST["password"];

        $table = ($usertype === "admin") ? "admin" : "customer";

        $sql = "INSERT INTO $table (username, password) VALUES (:username, :password)";
        $stmt = $pdo_user->prepare($sql);
        $stmt->execute([
            ":username" => $username,
            ":password" => $password
        ]);

        echo "SUCCESS";
    }
} catch (Exception $e) {
    echo "ERROR: " . $e->getMessage(); // 🔥 RETURNS ERROR TO CONSOLE
}
?>
