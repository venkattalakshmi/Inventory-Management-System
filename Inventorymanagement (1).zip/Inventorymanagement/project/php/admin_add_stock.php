<?php
require "db.php";
$data = json_decode(file_get_contents("php://input"), true);

$stmt = $pdo->prepare("
    UPDATE inventory_schema.item 
    SET quantity = quantity + 12 
    WHERE product_name=? AND model=?
");
$stmt->execute([$data["product_name"], $data["model"]]);

echo "Stock updated successfully!";
