<?php
require "db.php";

header("Content-Type: application/json");

$category = $_GET['category'] ?? '';

if (!$category) {
    echo json_encode([]);
    exit;
}

// Fetch all products with their models in the selected category
$sql = "SELECT product_name, model, price, quantity, unit, description 
        FROM item 
        WHERE category = ? AND quantity > 0"; // only available stock
$stmt = $pdo_inv->prepare($sql);
$stmt->execute([$category]);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($rows);
