<?php
// php/db.php
$DB_HOST = 'localhost';
$DB_PORT = '3306';
$DB_USER = 'root';
$DB_PASS = 'Thisanthan@123';

$DB_OPTIONS = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
];

try {
    // userdetail schema
    $pdo_user = new PDO(
        "mysql:host={$DB_HOST};port={$DB_PORT};dbname=userdetail;charset=utf8mb4",
        $DB_USER,
        $DB_PASS,
        $DB_OPTIONS
    );

    // inventory_schema
    $pdo_inv = new PDO(
        "mysql:host={$DB_HOST};port={$DB_PORT};dbname=inventory_schema;charset=utf8mb4",
        $DB_USER,
        $DB_PASS,
        $DB_OPTIONS
    );

} catch (PDOException $e) {
    die("DB Connection failed: " . $e->getMessage());
}
?>
