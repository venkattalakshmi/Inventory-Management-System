document.addEventListener("DOMContentLoaded", () => {
    let regpass = document.getElementById("regpass");
    let strengthText = document.getElementById("strengthText");

    if (regpass) {
        regpass.addEventListener("input", () => {
            let p = regpass.value;
            let strength = "";

            if (p.length < 8) strength = "❌ Weak – Minimum 8 characters";
            else if (!/[A-Z]/.test(p)) strength = "❌ Add at least 1 uppercase letter";
            else if (!/[0-9]/.test(p)) strength = "❌ Add at least 1 number";
            else strength = "✅ Strong password!";

            strengthText.innerHTML = strength;
        });
    }
});
